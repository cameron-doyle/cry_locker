Thanks for using cry locker.

INSTALL:
1. place zip in desired install location.
2. extract zip
3. run setup.exe

There are three methods to use this program:
1. Run the exe directly.
2. run "cry_locker" from cmd.
3. right click on a file/folder to encrypt and decrypt.

For help, run "help"

NOTE:
This is a beta, I don't assume any responsbility for damages or loss of data.
I have done my best to ensure quality work and risk of losing data is minimal.
Please make sure to decrypt a locker to validate that the password works,
and the data is intact before deleting the original data!
Also consider having the original data stored somewhere safe.